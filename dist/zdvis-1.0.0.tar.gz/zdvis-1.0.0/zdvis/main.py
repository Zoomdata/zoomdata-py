#/usr/bin/python3
from src import ZDVisualization
ZD = ZDVisualization()
