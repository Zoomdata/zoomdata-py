#/usr/bin/python3
from .main import ZD
