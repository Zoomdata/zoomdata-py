from distutils.core import setup
setup(
        name = 'zdvis',
        version = '1.0.0',
        packages = ['zdvis'],
        author = 'Aktiun',
        author_email = 'eduardo@aktiun.com',
        url = 'https://github.com/Zoomdata/ZDvis',
        description = 'Integrates Zoomdata visualizations into Jupyter notebooks'
        )
